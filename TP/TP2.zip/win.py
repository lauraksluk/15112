import copy

#winning hand = 1 pair of 2 tiles + 4 sets of 3 (pong's or chi's)

def hasPongSet(L):
    for c in L:
        if L.count(c) == 3:
            return True

def pongSetCount(L):
    pongSets = set()
    L.sort()
    for c in L:
        if L.count(c) == 3:
            pongSets.add(c)
    return len(pongSets)

def pairCount(L):
    pairSets = set()
    L.sort()
    for c in L:
        if L.count(c) == 2:
            pairSets.add(c)
    return len(pairSets)

def chiSetCount(L):
    count = 0
    wanCards,tongCards,bamCards,wordCards = [],[],[],[]
    for c in L:
        if c != None:
            if 'wan' in c:
                wanCards.append(c)
            elif 'tong' in c:
                tongCards.append(c)
            elif 'bam' in c:
                bamCards.append(c)
            else:
                wordCards.append(c)
    wanCards.sort()
    for card1 in wanCards:
        consec1 = 'wan' + str(int(card1[-1]) + 1)
        consec2 = 'wan' + str(int(consec1[-1]) + 1)
        if consec1 in wanCards and consec2 in wanCards:
            count += 1
            wanCards.remove(card1)
            wanCards.remove(consec1)
            wanCards.remove(consec2)
    tongCards.sort()
    for card2 in tongCards:
        consec3 = 'tong' + str(int(card2[-1]) + 1)
        consec4 = 'tong' + str(int(consec3[-1]) + 1)
        if consec3 in tongCards and consec4 in tongCards:
            count += 1
            tongCards.remove(card2)
            tongCards.remove(consec3)
            tongCards.remove(consec4)
    bamCards.sort()
    for card3 in bamCards:
        consec5 = 'bam' + str(int(card3[-1]) + 1)
        consec6 = 'bam' + str(int(consec5[-1]) + 1)
        if consec5 in bamCards and consec6 in bamCards:
            count += 1
            bamCards.remove(card3)
            bamCards.remove(consec5)
            bamCards.remove(consec6)
    leftover = wanCards + tongCards + bamCards + wordCards
    return count,leftover

def isWin(L,tile):
    L1 = copy.deepcopy(L)
    L1.append(tile)
    c1,leftover = chiSetCount(L1)
    p1 = pongSetCount(leftover)
    pair = pairCount(leftover)
    if (c1+p1) == 4 and pair == 1:
        if c1*3+p1*3+pair*2 == 14:
            return True
    else:
        return False

# hand = ['wan1', 'wan2', "wan3", 'wan4', 'wan5','wan6','bam1', 'bam1', 'bam1', 'wan4', 'wan4', 'wan4', 'green']
# playedTile = "green"
#
# print(isWin(hand,playedTile))

