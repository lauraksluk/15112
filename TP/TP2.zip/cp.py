from tkinter import *
import copy
import math
import random
import string

from player import *
from pong import *
from chi import *


def markChiSets(L):
    done = []
    copyL = copy.deepcopy(L)
    wanT,tongT,bamT,wordT = groupSets(copyL)
    wanT.sort()
    for i in range(len(wanT)-2):
        n = getNumberFromTile(wanT[i])
        if n + 1 == int(wanT[i+1][-1]) and n + 2 == int(wanT[i+2][-1]):
            if wanT[i] in copyL and wanT[i+1] in copyL and wanT[i+2] in copyL:
                done += [wanT[i],wanT[i+1],wanT[i+2]]
                copyL.remove(wanT[i])
                copyL.remove(wanT[i+1])
                copyL.remove(wanT[i+2])
    tongT.sort()
    for j in range(len(tongT)-2):
        m = getNumberFromTile(tongT[j])
        if m + 1 == int(tongT[j+1][-1]) and m + 2 == int(tongT[j+2][-1]):
            if tongT[j] in copyL and tongT[j+1] in copyL and tongT[j+2] in copyL:
                done += [tongT[j],tongT[j+1],tongT[j+2]]
                copyL.remove(tongT[j])
                copyL.remove(tongT[j+1])
                copyL.remove(tongT[j+2])
    bamT.sort()
    for k in range(len(bamT)-2):
        p = getNumberFromTile(bamT[k])
        if p + 1 == int(bamT[k+1][-1]) and p + 2 == int(bamT[k+2][-1]):
            if bamT[k] in copyL and bamT[k+1] in copyL and bamT[k+2] in copyL:
                done += [bamT[k],bamT[k+1],bamT[k+2]]
                copyL.remove(bamT[k])
                copyL.remove(bamT[k+1])
                copyL.remove(bamT[k+2])
    return done,copyL

def markPongSets(done,copyL):
    temp = copy.deepcopy(copyL)
    for t in temp:
        if temp.count(t) >= 3:
            if copyL.count(t) >= 3:
                done += [t,t,t]
                index = copyL.index(t)
                copyL.pop(index)
                copyL.pop(index)
                copyL.pop(index)
    return done,copyL

def compIncSets(L):
    done,lst = markChiSets(L)
    complete,non = markPongSets(done,lst)
    return complete,non

def hasConsecutiveTiles(L):
    for i in range(len(L)-2):
        n = getNumberFromTile(L[i])
        if n + 1 == int(L[i+1][-1]) and n + 2 == int(L[i+2][-1]):
            return True
    return False

def addChiToComplete(complete,left,L):
    for i in range(len(L)-2):
        n = getNumberFromTile(L[i])
        if n + 1 == int(L[i+1][-1]) and n + 2 == int(L[i+2][-1]):
            if L[i] in left and L[i+1] in left and L[i+2] in left:
                left.remove(L[i])
                left.remove(L[i+1])
                left.remove(L[i+2])
                complete += [L[i],L[i+1],L[i+2]]

def addPongToComplete(complete,left,L):
    for t in L:
        if L.count(t) >= 3:
            if left.count(t) >= 3:
                complete += [t,t,t]
                index = left.index(t)
                left.pop(index)
                left.pop(index)
                left.pop(index)

def cpThrow(complete,leftover,newTile):
    leftover.append(newTile)
    wanTemp,tongTemp,bamTemp,wordTemp = groupSets(leftover)
    wanTemp.sort(),tongTemp.sort(),bamTemp.sort(),wordTemp.sort()
    if hasConsecutiveTiles(wanTemp):
        addChiToComplete(complete,leftover,wanTemp)
    if hasConsecutiveTiles(tongTemp):
        addChiToComplete(complete,leftover,tongTemp)
    if hasConsecutiveTiles(bamTemp):
        addChiToComplete(complete,leftover,bamTemp)
    elif leftover.count(newTile) >= 3:
        addPongToComplete(complete,leftover,wanTemp)
        addPongToComplete(complete,leftover,tongTemp)
        addPongToComplete(complete,leftover,bamTemp)
        addPongToComplete(complete,leftover,wordTemp)
    throw = random.choice(leftover)
    return throw

def cp1Throw(data,new=''):
    if isCp1Chi(data) == False and isCp1Pong(data) == False:
        data.throw = cpThrow(data.cp1Complete,data.cp1Inc,new)
    else:
        data.throw = random.choice(data.cp1Inc)
    print(data.cp1Hand,data.throw)
    data.discarded.append(data.throw)
    data.cp1Hand.remove(data.throw)
    data.cp1Inc.remove(data.throw)
    data.nextPlayer = 'cp2'
    data.player,data.cp1,data.cp3 = False,False,False
    data.cp2 = True
    data.cpPong = False
    data.cpChi = False

def cp2Throw(data,new=''):
    if isCp2Chi(data) == False and isCp2Pong(data) == False:
        data.throw = cpThrow(data.cp2Complete,data.cp2Inc,new)
    else:

        data.throw = random.choice(data.cp2Inc)
    data.discarded.append(data.throw)
    data.cp2Hand.remove(data.throw)
    data.cp2Inc.remove(data.throw)
    data.nextPlayer = 'cp3'
    data.player = False
    data.cp1 = False
    data.cp2 = False
    data.cp3 = True
    data.cpPong = False
    data.cpChi = False

def cp3Throw(data,new=''):
    if isCp2Chi(data) == False and isCp2Pong(data) == False:
        data.throw = cpThrow(data.cp3Complete,data.cp3Inc,new)
    else:
        data.throw = random.choice(data.cp3Inc)
    data.discarded.append(data.throw)
    data.cp3Hand.remove(data.throw)
    data.cp3Inc.remove(data.throw)
    data.nextPlayer = 'player'
    data.cp1 = False
    data.cp2 = False
    data.cp3 = False
    data.cpPong = False
    data.cpChi = False
    data.playerTookTile = False
    data.player = True

def cp1OnTimerFired(data):
    if data.p1Pong == False and data.p1Chi == False:
        if data.cpPong == False and data.cpChi == False and data.playerTookTile == False \
        and data.cp1:
            if len(data.cp1Hand) == 13-len(data.cp1Pong)-len(data.cp1Chi):
                new1 = getNewTile(data)
                data.cp1Hand.append(new1)
                cp1Throw(data,new1)
        elif isCp1Pong(data):
            data.cp1Pong.append(data.cp1Hand.remove(data.throw))
            data.cp1Inc.remove(data.throw)
            data.cp1Pong.append(data.cp1Hand.remove(data.throw))
            data.cp1Inc.remove(data.throw)
            data.cp1Pong.append(data.discarded.pop())
            data.cpPong = True
            data.cp1 = True
            cp1Throw(data)
        elif isCp1Chi(data):
            elem1,elem2 = getChiTiles(data.cp1Inc,data.throw)
            data.cp1Chi.append(data.cp1Hand.remove(elem1))
            data.cp1Inc.remove(elem1)
            data.cp1Chi.append(data.cp1Hand.remove(elem2))
            data.cp1Inc.remove(elem2)
            data.cp1Chi.append(data.discarded.pop())
            data.cpChi = True
            data.cp1 = True
            cp1Throw(data)

def cp2OnTimerFired(data):
    if data.p1Pong == False and data.p1Chi == False:
        if data.cpPong == False and data.cpChi == False and data.cp2 == True:
            if(len(data.cp2Hand) == 13-len(data.cp2Pong)-len(data.cp2Chi)):
                new2 = getNewTile(data)
                data.cp2Hand.append(new2)
                cp2Throw(data,new2)
        elif isCp2Pong(data):
            data.cp2Pong.append(data.cp2Hand.remove(data.throw))
            data.cp2Inc.remove(data.throw)
            data.cp2Pong.append(data.cp2Hand.remove(data.throw))
            data.cp2Inc.remove(data.throw)
            data.cp2Pong.append(data.discarded.pop())
            data.cpPong = True
            data.cp2 = True
            cp2Throw(data)
        elif isCp2Chi(data):
            elem1,elem2 = getChiTiles(data.cp2Inc,data.throw)
            data.cp2Chi.append(data.cp2Hand.remove(elem1))
            data.cp2Inc.remove(elem1)
            data.cp2Chi.append(data.cp2Hand.remove(elem2))
            data.cp2Inc.remove(elem2)
            data.cp2Chi.append(data.discarded.pop())
            data.cpChi = True
            data.cp2 = True
            cp2Throw(data)


def cp3OnTimerFired(data):
    if data.p1Pong == False and data.p1Chi == False:
        if data.cpPong == False and data.cpChi == False and data.cp3 == True:
            if (len(data.cp3Hand) == 13-len(data.cp3Pong)-len(data.cp3Chi)):
                new3 = getNewTile(data)
                data.cp3Hand.append(new3)
                cp3Throw(data,new3)
        elif isCp3Pong(data):
            data.cp3Pong.append(data.cp3Hand.remove(data.throw))
            data.cp3Inc.remove(data.throw)
            data.cp3Pong.append(data.cp3Hand.remove(data.throw))
            data.cp3Inc.remove(data.throw)
            data.cp3Pong.append(data.discarded.pop())
            data.cpPong = True
            data.cp3 = True
            cp3Throw(data)
        elif isCp3Chi(data):
            elem1,elem2 = getChiTiles(data.cp3Inc,data.throw)
            data.cp3Chi.append(data.cp3Hand.remove(elem1))
            data.cp3Inc.remove(elem1)
            data.cp3Chi.append(data.cp3Hand.remove(elem2))
            data.cp3Inc.remove(elem2)
            data.cp3Chi.append(data.discarded.pop())
            data.cpChi = True
            data.cp3 = True
            cp3Throw(data)

def cp1RedrawAll(canvas,data):
    canvas.create_rectangle(500,75,500+25,75+25,fill='grey')
    canvas.create_text((500+525)//2,(75+100)//2,text="CP1",fill='white')

def cp2RedrawAll(canvas,data):
    canvas.create_rectangle(120,50,120+25,50+25,fill='grey')
    canvas.create_text((120+145)//2,(50+75)//2,text="CP2",fill='white')

def cp3RedrawAll(canvas,data):
    canvas.create_rectangle(75,100,75+25,100+25,fill='grey')
    canvas.create_text((75+100)//2,(100+125)//2,text="CP3",fill='white')








