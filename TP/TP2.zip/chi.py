def groupSets(L):
    wanGroup, tongGroup, bambooGroup, wordGroup = [],[],[],[]
    for tile in L:
        if 'wan' in tile:
            wanGroup.append(tile)
        elif 'tong' in tile:
            tongGroup.append(tile)
        elif 'bam' in tile:
            bambooGroup.append(tile)
        else:
            wordGroup.append(tile)
    return wanGroup,tongGroup,bambooGroup,wordGroup

def getNumberFromTile(s):
    return int(s[-1])

def getChiTiles(L,givenTile):
    n = getNumberFromTile(givenTile)
    if 'wan' in givenTile:
        getPossibleChiTiles(L,n,'wan')
    elif 'tong' in givenTile:
        getPossibleChiTiles(L,n,'tong')
    elif 'bam' in givenTile:
        getPossibleChiTiles(L,n,'bam')

def getPossibleChiTiles(L,n,s):
    if (s + str(n+1)) in L and (s + str(n+2)) in L:
        elem1 = s + str(n+1)
        elem2 = s + str(n+2)
    elif (s + str(n-1)) in L and (s + str(n-2)) in L:
        elem1 = s + str(n-1)
        elem2 = s + str(n-2)
    elif (s + str(n+1)) in L and (s + str(n-1)) in L:
        elem1 = s + str(n+1)
        elem2 = s + str(n-1)
    return elem1,elem2

def getHandChiTiles(L,n,s):
    if (s + str(n+1)) in L and (s + str(n+2)) in L:
        return True
    elif (s + str(n-1)) in L and (s + str(n-2)) in L:
        return True
    elif (s + str(n+1)) in L and (s + str(n-1)) in L:
        return True
    else:
        return False

def isChi(L,givenTile):
    if 'wan' in givenTile:
        n = getNumberFromTile(givenTile)
        getHandChiTiles(L,n,'wan')
    elif 'tong' in givenTile:
        m = getNumberFromTile(givenTile)
        getHandChiTiles(L,m,'tong')
    elif 'bam' in givenTile:
        p = getNumberFromTile(givenTile)
        getHandChiTiles(L,p,'bam')
    else:
        return False

def isPlayerChi(data):
    if data.nextPlayer == 'player' and isChi(data.playerHand,data.throw) == True:
        data.cpChi = False
        data.p1Chi = True
        return True
    else:
        return False

def isCp1Chi(data):
    if data.nextPlayer == 'cp1' and isChi(data.cp1Inc,data.throw) == True:
        data.cp1Chi = True
        return True
    else:
        return False

def isCp2Chi(data):
    if data.nextPlayer == 'cp2' and isChi(data.cp2Inc,data.throw) == True:
        data.cp2Chi = True
        return True
    else:
        return False

def isCp3Chi(data):
    if data.nextPlayer == 'cp3' and isChi(data.cp3Inc,data.throw) == True:
        data.cp3Chi = True
        return True
    else:
        return False

def chiRedrawAll(canvas,data):
    if data.cpPong == False:
        if isCp1Chi(data) == True or isCp2Chi(data) == True or isCp3Chi(data) == True:
            data.cpChi = True
        if isPlayerChi(data) == True:
            canvas.create_text(data.width//2,data.height//2, text="Chi?", font = "BrushScriptMT 20", fill = "white")
            canvas.create_text(data.width//2, data.height//2 + 50, text = "Click tiles to Chi!", font = "BrushScriptMT 20", fill = "white")

        if isCp1Chi(data):

            canvas.create_rectangle(550,200,550+25,200+25,fill='grey')
            canvas.create_text((550+575)//2,(200+225)//2,text="CHI!",fill='white')
        elif isCp2Chi(data):

            canvas.create_rectangle(200,75,200+25,75+25,fill='grey')
            canvas.create_text((200+225)//2,(75+100)//2,text="CHI!",fill='white')
        elif isCp3Chi(data):

            canvas.create_rectangle(100,100,100+25,100+25,fill='grey')
            canvas.create_text((100+125)//2,(100+125)//2,text="CHI!",fill='white')




















