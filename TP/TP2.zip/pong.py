from chi import *
def isPong(L,givenTile):
    if L.count(givenTile) >= 2:
        return True

def multiplePongs(data):
    if isCp1Pong == True and isCp2Pong == True:
        return not(isCp1Pong)
    elif isCp2Pong == True and isCp3Pong == True:
        return not (isCp2Pong)
    elif isCp1Pong == True and isCp3Pong == True:
        return not (isCp3Pong)
    elif isCp1Pong == True and isCp2Pong == True and isCp3Pong == True:
        return not(isCp1Pong) and not(isCp2Pong)

def isPlayerPong(data):
    if data.nextPlayer != 'cp1' and isPong(data.playerHand,data.throw) == True:
        data.p1Pong = True
        return True
    else:
        return False

def isCp1Pong(data):
    if data.cp1 == False and data.nextPlayer != 'cp2' and \
    isPong(data.cp1Inc,data.throw) == True:
        return True
    else:
        return False

def isCp2Pong(data):
    if data.cp2 == False and data.nextPlayer != 'cp3' and \
    isPong(data.cp2Inc,data.throw) == True:
        return True
    else:
        return False

def isCp3Pong(data):
    if data.cp3 == False and data.nextPlayer != 'player' and \
    isPong(data.cp3Inc,data.throw) == True:
        return True
    else:
        return False

def pongRedrawAll(canvas,data):
    if data.cpPong == True and data.cpChi == True:
        data.cpChi = False
    if isCp1Pong(data) == True or isCp2Pong(data) == True or isCp3Pong(data) == True:
        data.cpPong = True
    if isPlayerPong(data):
        canvas.create_text(data.width//2,data.height//2, text="Pong?", font = "BrushScriptMT 20", fill = "white")
        canvas.create_text(data.width//2, data.height//2 + 50, text = "Click tiles to pong!", font = "BrushScriptMT 20", fill = "white")
    multiplePongs(data)
    if data.cpPong == True:
        if isCp1Pong(data):
            canvas.create_rectangle(550,200,550+20,200+20,fill='grey')
            canvas.create_text((550+570)//2,(200+220)//2,text="PONG!",fill='white')
        elif isCp2Pong(data):
            canvas.create_rectangle(200,75,200+20,75+20,fill='grey')
            canvas.create_text((200+220)//2,(75+95)//2,text="PONG!",fill='white')
        elif isCp3Pong(data):
            canvas.create_rectangle(100,100,100+20,100+20,fill='grey')
            canvas.create_text((100+120)//2,(100+120)//2,text="PONG!",fill='white')











