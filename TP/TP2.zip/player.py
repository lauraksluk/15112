from tkinter import *
#import tkinter as tk
from PIL import ImageTk, Image
#import glob
import random
from pong import *
from chi import *
from win import *

def init(data):
    data.tileWidth = 35
    data.tileHeight = 50


def getTiles(data):
    data.tiles = ['wan1','wan2','wan3','wan4','wan5','wan6','wan7','wan8','wan9',\
    'wan1','wan2','wan3','wan4','wan5','wan6','wan7','wan8','wan9',\
    'wan1','wan2','wan3','wan4','wan5','wan6','wan7','wan8','wan9',\
    'wan1','wan2','wan3','wan4','wan5','wan6','wan7','wan8','wan9',\
    'tong1','tong2','tong3','tong4','tong5','tong6','tong7','tong8','tong9',\
    'tong1','tong2','tong3','tong4','tong5','tong6','tong7','tong8','tong9',\
    'tong1','tong2','tong3','tong4','tong5','tong6','tong7','tong8','tong9',\
    'tong1','tong2','tong3','tong4','tong5','tong6','tong7','tong8','tong9',\
    'bam1','bam2','bam3','bam4','bam5','bam6','bam7','bam8','bam9',\
    'bam1','bam2','bam3','bam4','bam5','bam6','bam7','bam8','bam9',\
    'bam1','bam2','bam3','bam4','bam5','bam6','bam7','bam8','bam9',\
    'bam1','bam2','bam3','bam4','bam5','bam6','bam7','bam8','bam9',\
    'east','south','west','north','red','green','blank',\
    'east','south','west','north','red','green','blank',\
    'east','south','west','north','red','green','blank',\
    'east','south','west','north','red','green','blank']
    player = []
    for i in range(14):
        cardP = random.choice(data.tiles)
        player.append(cardP)
        data.tiles.remove(cardP)
    player = orderHand(player)
    if None in player:
        player.remove(None)
    cp1 = []
    for j in range(13):
        card1 = random.choice(data.tiles)
        cp1.append(card1)
        data.tiles.remove(card1)
    cp1 = orderHand(cp1)
    if None in cp1:
        cp1.remove(None)
    cp2 = []
    for k in range(13):
        card2 = random.choice(data.tiles)
        cp2.append(card2)
        data.tiles.remove(card2)
    cp2 = orderHand(cp2)
    if None in cp2:
        cp2.remove(None)
    cp3 = []
    for l in range(13):
        card3 = random.choice(data.tiles)
        cp3.append(card3)
        data.tiles.remove(card3)
    cp3 = orderHand(cp3)
    if None in cp3:
        cp3.remove(None)
    return [player,cp1,cp2,cp3]

def orderHand(L):
    L1,L2,L3,L4 = [],[],[],[]
    for tile in L:
        if 'wan' in tile:
            L1.append(tile)
            L1.sort()
        elif 'bam' in tile:
            L2.append(tile)
            L2.sort()
        elif 'tong' in tile:
            L3.append(tile)
            L3.sort()
        else:
            L4.append(tile)
            L4.sort()
    result = L1+L2+L3+L4
    return result

def getNewTile(data):
    tile = random.choice(data.tiles)
    data.tiles.remove(tile)
    return tile

def playerThrow(event,data):
    if 425 < event.y < 425 + data.tileHeight:
        if data.player == True or data.playerTookTile == True:
            data.tileNum = (event.x - 60) // data.tileWidth
            data.throw = data.playerHand.pop(data.tileNum)
            data.discarded.append(data.throw)
            data.nextPlayer = "cp1"
            data.player = False
            data.p1Pong = False
            data.p1Chi = False
            data.playerTookTile = False
            data.cp2 = False
            data.cp3 = False
            data.cp1 = True

def playerMousePressed(event, data):
    if isPlayerPong(data) == True and data.p1Pong == True:
        TileNum1 = (event.x - 60) // data.tileWidth
        data.playerTookTile = True
        data.playerPong.append(data.playerHand.pop(TileNum1))
        data.playerPong.append(data.discarded.pop())
        TileNum2 = TileNum1 + 1
        data.playerPong.append(data.playerHand.pop(TileNum2))
        playerThrow(event,data)
    elif isPlayerChi(data) == True and data.p1Chi == True:
        TileNum1 = (event.x - 60) // data.tileWidth
        data.playerTookTile = True
        data.playerChi.append(data.playerHand.pop(TileNum1))
        data.playerChi.append(data.discarded.pop())
        TileNum2 = TileNum1 + 1
        data.playerChi.append(data.playerHand.pop(TileNum2))
        playerThrow(event,data)
    playerThrow(event,data)
    pass

def playerKeyPressed(event, data):
    if event.keysym == 'space':
        if isPlayerPong(data):
            data.playerTookTile = False
            data.p1Pong = False
        if isPlayerChi(data):
            data.playerTookTile = False
            data.p1Chi = False
    pass

def playerOnTimerFired(data):
    if data.cpPong == False and data.cpChi == False and data.player == True \
    and data.p1Pong == False and data.p1Chi == False:
        if len(data.playerHand) == 13-len(data.playerPong)-len(data.playerChi):
            data.playerHand.append(getNewTile(data))
            data.playerHand = orderHand(data.playerHand)

def drawPlayer(canvas,data):
    result = []
    tileWidth = 35
    tileHeight = 50
    for i in range(len(data.playerHand)):
        x0 = 60 + tileWidth*i
        y0 = 425
        x1 = x0 + tileWidth
        y1 = y0 + tileHeight
        canvas.create_rectangle(x0,y0,x1,y1,fill='white')
        canvas.create_text((x0+x1)//2,(y0+y1)//2,text=data.playerHand[i])

def winRedrawAll(canvas,data):
    pass












