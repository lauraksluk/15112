from tkinter import *
#import tkinter as tk
from PIL import ImageTk, Image
#import glob
import random
#from startScreen import *

def getTiles(num):
    tiles = ['w1','w2','w3','w4','w5','w6','w7','w8','w9','t1','t2','t3', \
    't4','t5','t6','t7','t8','t9','b1','b2','b3','b4','b5','b6','b7','b8', \
    'b9','east','south','west','north','red','green','blank']
    result = []
    for i in range(num):
        card = random.choice(tiles)
        result.append(card)
        tiles.remove(card)
    return result

def drawHand(canvas,data,L1,L2,x,y):
    L1 = data.tiles
    canvas.image1 = ImageTk.PhotoImage(L[0])
    canvas.create_image(x,y,image=canvas.image1)

    canvas.image2 = ImageTk.PhotoImage(L[1])
    canvas.create_image(x+35,y,image=canvas.image2)

    canvas.image3 = ImageTk.PhotoImage(L[2])
    canvas.create_image(x+2*35,y,image=canvas.image3)

    canvas.image4 = ImageTk.PhotoImage(L[3])
    canvas.create_image(x+3*35,y,image=canvas.image4)

    canvas.image5 = ImageTk.PhotoImage(L[4])
    canvas.create_image(x+4*35,y,image=canvas.image5)

    canvas.image6 = ImageTk.PhotoImage(L[5])
    canvas.create_image(x+5*35,y,image=canvas.image6)

    canvas.image7 = ImageTk.PhotoImage(L[6])
    canvas.create_image(x+6*35,y,image=canvas.image7)

def drawPlayer(canvas,data):
    result = []
    tileWidth = 35
    tileHeight = 50
    for i in range(len(data.player)):
        x0 = 60 + tileWidth*i
        y0 = 425
        x1 = x0 + tileWidth
        y1 = y0 + tileHeight
        canvas.create_rectangle(x0,y0,x1,y1,outline='white',fill='lime green')
        tile = data.player[i]
        drawHand(canvas,data.tiles,)
        for pic in data.tiles:
            if pic[0] == tile + '.png':
                img = pic[1]
                canvas.image = ImageTk.PhotoImage(img)
                canvas.create_image((x0+x1)//2,(y0+y1)//2,image=canvas.image)

def openTile():
    result = []
    tiles = ['w1','w2','w3','w4','w5','w6','w7','w8','w9','t1','t2','t3', \
    't4','t5','t6','t7','t8','t9','b1','b2','b3','b4','b5','b6','b7','b8', \
    'b9','east','south','west','north','red','green','blank']
    for s in tiles:
        file = s + '.png'
        img = Image.open(file)
        result.append([file,img])
    return result


def init(data):
    data.tiles = openTile()
    data.player = getTiles(14)
    data.cp1 = getTiles(13)
    data.cp2 = getTiles(13)
    data.cp3 = getTiles(13)
    pass

def mousePressed(event, data):
    # use event.x and event.y
    pass

def keyPressed(event, data):
    # use event.char and event.keysym
    pass

def timerFired(data):
    pass

def drawCenterTiles(canvas,data):
    tileWidth = 15
    tileHeight = 25
    for i in range(18):
        x0 = data.width/3.6 + tileWidth*i
        y0 = data.height*3//20 + tileHeight
        x1 = x0 + tileWidth
        y1 = y0 + tileHeight
        canvas.create_rectangle(x0,y0,x1,y1,fill='darkgreen')
    for j in range(18):
        x2 = data.width/3.6 - tileHeight
        y2 = data.height*3//20 + tileHeight + tileWidth*j
        x3 = x2 + tileHeight
        y3 = y2 + tileWidth
        canvas.create_rectangle(x2,y2,x3,y3,fill='darkgreen')
    for k in range(18):
        x4 = data.width/3.6 + tileWidth*k
        y4 = data.height*3//20 + 18*tileWidth
        x5 = x4 + tileWidth
        y5 = y4 + tileHeight
        canvas.create_rectangle(x4,y4,x5,y5,fill='darkgreen')
    for l in range(18):
        x6 = data.width/3.6 + 18*tileWidth
        y6 = data.height*3//20 + tileHeight + tileWidth*l
        x7 = x6 + tileHeight
        y7 = y6 + tileWidth
        canvas.create_rectangle(x6,y6,x7,y7,fill='darkgreen')

def drawCPTiles(canvas,data):
    tileWidth = 15
    tileHeight = 25
    for i in range(13):
        x0 = data.width/3.6 + 2.5*tileWidth + tileWidth*i
        y0 = data.height//10
        x1 = x0 + tileWidth
        y1 = y0 + tileHeight
        canvas.create_rectangle(x0,y0,x1,y1,fill='darkgreen')
    for j in range(13):
        x2 = data.width/3.6 - 3*tileHeight
        y2 = data.height*3//20 + 2.5*tileHeight + tileWidth*j
        x3 = x2 + tileHeight
        y3 = y2 + tileWidth
        canvas.create_rectangle(x2,y2,x3,y3,fill='darkgreen')
    for k in range(13):
        x4 = data.width/3.6 + 18*tileWidth + 2*tileHeight
        y4 = data.height*3//20 + 2.5*tileHeight + tileWidth*k
        x5 = x4 + tileHeight
        y5 = y4 + tileWidth
        canvas.create_rectangle(x4,y4,x5,y5,fill='darkgreen')


def redrawAll(canvas, data):
    canvas.create_rectangle(0,0,data.width,data.height,fill='lime green')
    drawCenterTiles(canvas,data)
    drawCPTiles(canvas,data)

    drawPlayer(canvas,data)
    pass

def run(width=300, height=300):
    def redrawAllWrapper(canvas, data):
        canvas.delete(ALL)
        canvas.create_rectangle(0, 0, data.width, data.height,
                                fill='white', width=0)
        redrawAll(canvas, data)
        canvas.update()

    def mousePressedWrapper(event, canvas, data):
        mousePressed(event, data)
        redrawAllWrapper(canvas, data)

    def keyPressedWrapper(event, canvas, data):
        keyPressed(event, data)
        redrawAllWrapper(canvas, data)

    def timerFiredWrapper(canvas, data):
        timerFired(data)
        redrawAllWrapper(canvas, data)
        # pause, then call timerFired again
        canvas.after(data.timerDelay, timerFiredWrapper, canvas, data)
    # Set up data and call init
    class Struct(object): pass
    data = Struct()
    data.width = width
    data.height = height
    data.timerDelay = 100 # milliseconds
    root = Tk()
    init(data)
    # create the root and the canvas
    canvas = Canvas(root, width=data.width, height=data.height)
    canvas.configure(bd=0, highlightthickness=0)
    canvas.pack()
    # set up events
    root.bind("<Button-1>", lambda event:
                            mousePressedWrapper(event, canvas, data))
    root.bind("<Key>", lambda event:
                            keyPressedWrapper(event, canvas, data))
    timerFiredWrapper(canvas, data)
    # and launch the app
    root.mainloop()  # blocks until window is closed
    print("bye!")

run(600,500)