from tkinter import *
from PIL import ImageTk, Image
import random

class Tile(object):
    def __init__(self,kind,name):
        self.kind = kind
        self.name = name

    def __eq__(self,other):
        return self.kind == other.kind and self.name == other.name

    def canPong(self,other,L):
        if __eq__(self,other) and L.count(self) == 2:
            return True
        else:
            return False

    def displayTile():
        tiles = ['w1','w2','w3','w4','w5','w6','w7','w8','w9','t1','t2','t3', \
        't4','t5','t6','t7','t8','t9','b1','b2','b3','b4','b5','b6','b7','b8', \
        'b9','east','south','west','north','red','green','blank']
        for s in tiles:
            file = s + '.png'
            img = Image.open(file)
            #img = img.resize((35,50),Image.ANTIALIAS)
            photo = ImageTk.PhotoImage(img)
            label = Label(image=photo)
            label.image = photo
            label.pack()

class Wan(Tile):
    def __init__(self,kind,name):
        self.kind = 'wan'
        self.name = name

class Tong(Tile):
    def __init(self,kind,name):
        self.kind = 'tong'
        self.name = name

class Bamboo(Tile):
    def __init__(self,kind,name):
        self.kind = 'bamboo'
        self.name = name

class Word(Tile):
    def __init__(self,kind,name):
        self.kind = 'word'
        self.name = name



