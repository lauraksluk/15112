from tkinter import *
from PIL import ImageTk, Image
import random

class Player(object):
    def __init__(self):


    def getTiles(num):
        tiles = ['w1','w2','w3','w4','w5','w6','w7','w8','w9','t1','t2','t3', \
        't4','t5','t6','t7','t8','t9','b1','b2','b3','b4','b5','b6','b7','b8', \
        'b9','east','south','west','north','red','green','blank']
        result = []
        for i in range(num):
            card = random.choice(tiles)
            result.append(card)
            tiles.remove(card)
        return result

    def drawPlayer(canvas,data):
        tileWidth = 35
        tileHeight = 50
        for i in range(2):
            x0 = 60 + tileWidth*i
            y0 = 425
            x1 = x0 + tileWidth
            y1 = y0 + tileHeight
            canvas.create_rectangle(x0,y0,x1,y1,outline='white',fill='lime green')
            tile = data.player[i]
            tiles = ['w1','w2','w3','w4','w5','w6','w7','w8','w9','t1','t2','t3', \
            't4','t5','t6','t7','t8','t9','b1','b2','b3','b4','b5','b6','b7','b8', \
            'b9','east','south','west','north','red','green','blank']
            for j in tiles:
                if j == tile:
                    pic = data.tiles[j]
                    canvas.create_image((x0+x1)//2,(y0+y1)//2,image=pic)

def init(data):
    data.player = getTiles()

def mousePressed(event, data):
    # use event.x and event.y
    pass

def keyPressed(event, data):

    pass

def timerFired(data):
    pass

def redrawAll(canvas,data):
    drawPlayer(canvas,data)

